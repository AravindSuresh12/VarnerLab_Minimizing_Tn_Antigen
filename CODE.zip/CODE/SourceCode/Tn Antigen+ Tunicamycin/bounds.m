%bounds for the reactions. The driver code will change bounds(5,:) each run
%Units of bounds are in uM/h
%negative flux means reactants are coming IN, and gets consumed
%positive flux means reactants are going OUT, and gets generated

function bound= bounds
bounds= [-100	100
 0	 0.135 %changing the lb of transcription elongation to reflect effect of tunicamycin in the elongation process as an inhibitor
 -100	100
-100	100
 0.0585    0.0585  %change me here for TX Bounds as per constants file outputs
-100	100
-100	100
-100	100
-100    100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100    100
-100    100];
bound=bounds;