### A Pluto.jl notebook ###
# v0.19.4

using Markdown
using InteractiveUtils

# ╔═╡ 2b4f2d26-9445-4173-bf60-86d7c9353a79
function ingredients(path::String)
	
	# this is from the Julia source code (evalfile in base/loading.jl)
	# but with the modification that it returns the module instead of the last object
	name = Symbol("lib")
	m = Module(name)
	Core.eval(m,
        Expr(:toplevel,
             :(eval(x) = $(Expr(:core, :eval))($name, x)),
             :(include(x) = $(Expr(:top, :include))($name, x)),
             :(include(mapexpr::Function, x) = $(Expr(:top, :include))(mapexpr, $name, x)),
             :(include($path))))
	m
end

# ╔═╡ c9f4e2e7-64d4-437d-845e-5968e181c98d
begin
	# import some packages -
	using PlutoUI
	using PrettyTables
	using LinearAlgebra
	using DelimitedFiles
	# setup paths -
	const _PATH_TO_NOTEBOOK = pwd()
	const _PATH_TO_SRC = joinpath(_PATH_TO_NOTEBOOK,"src")
	
	# load the PS2 code lib -
	lib = ingredients(joinpath(_PATH_TO_SRC, "Include.jl"));

	# return -
	nothing
end

# ╔═╡ 75209531-76f3-4385-b153-0b0c9392c96b
begin
    reaction_array = Array{String,1}()
    
    #Gene Initiation, Transcription Degradation of mRNA and Translation Inititaion

    push!(reaction_array,"v1,GALNT1+RNAP,GALNT1(cat),false")
	push!(reaction_array,"v2,GALNT1(cat)+1226*ATP+1232*UTP+781*GTP+ 
	671*CTP,mRNA+ GALNT1 +RNAP+ 7820*Pi,true")
	push!(reaction_array,"v3,mRNA,1226*AMP+1232*UMP+781*GMP+671*CMP,false")
	push!(reaction_array,"v4,mRNA+rib,rib(cat),false")   

	#Translation, to minimize this

	 push!(reaction_array,"v5,rib(cat)+ 559*AA+ 1118*GTP+559*H20, 559*AAtRNA+ 
     1118*GDP+ 1118*Pi+rib+mRNA+ppGALNT1,false") 

    #charging of tRNA	 
     push!(reaction_array,"v6,559*AA+559*tRNA+559*ATP,559*AMP+559*PPi+559*AAtRNA,false")

	#production of Tn antigen- to check the flux of this after minimizing v5 

	push!(reaction_array,"v7,Polypeptide+UDP-Gal,Tn_Antigen+UDP,false")
	push!(reaction_array,"v8,T_synthase+Cosmc,T_complex, true")
	push!(reaction_array,"v9,Tn_Antigen+ Galactose +T_complex,T_Antigen + T_complex,true") #T_complex is T_synthase+Cosmc
	push!(reaction_array,"v10,T_synthase+Cosmc+A2d,T_complex_in, true")
	push!(reaction_array,"v11,Tn_Antigen+Galactose +T_complex_in,T_Antigen + T_complex_in,true") #T_complex_in is T_synthase+A2d+Cosmc comparison


	#exchange fluxes 
	push!(reaction_array,"e1,[],GALNT1,true")
	push!(reaction_array,"e2,[],RNAP,true")
	push!(reaction_array,"e3,[],ATP,true")
	push!(reaction_array,"e4,[],GTP,true")
	push!(reaction_array,"e5,[],UTP,true")
    push!(reaction_array,"e6,[],CTP,true")	
	push!(reaction_array,"e7,[],H20,true")
	push!(reaction_array,"e8,[],Pi,true")
	push!(reaction_array,"e9,ATP+H20,AMP+ PPi, false")
	push!(reaction_array,"e10,GTP+H20,GMP+ PPi, false")
	push!(reaction_array,"e11,CTP+H20,CMP+ PPi, false")
	push!(reaction_array,"e12,UTP+H20,UMP+ PPi, false")
	push!(reaction_array,"e13, 559*AAtRNA,559*AA, false")
    push!(reaction_array,"e14, 559*tRNA,[],true")
	push!(reaction_array,"e14, ppGALNT1,[],false") #partially goes out
	push!(reaction_array,"e15,PPi+H20,2*Pi,false")
	push!(reaction_array,"e16,[],AA,true")
	push!(reaction_array,"e17,ATP+UDP,UTP+ADP,false")
	push!(reaction_array,"e18,ATP+GDP,GTP+ADP,false")
	push!(reaction_array,"e19,ATP+CDP,CTP+ADP,false")
	push!(reaction_array,"e20,ATP+UMP,UDP+ADP,false")
	push!(reaction_array,"e21,[],rib,true")
	push!(reaction_array,"e22,ATP+CMP,ADP+CDP,false")
	push!(reaction_array,"e23,ATP+GMP,ADP+GDP,false")
	push!(reaction_array,"e24,ATP+UMP,UDP+ADP,false")
	push!(reaction_array,"e25,ATP+AMP,2*ADP,false")
	push!(reaction_array,"e26,UDP+AMP,2*ADP,false")

	#Leloir Mechanism to account for the production of UDP Gal

	push!(reaction_array,"e27,[],Glucose,true")
	push!(reaction_array,"e28,[],Galactose,true")
	push!(reaction_array,"e29,Glucose,Glucose-1P,false") #assuming all these enzymes are fed into the reaction, and they dont interact with ppGalNAcT1/ other components
	push!(reaction_array,"e30,Glucose-1P+UTP,UDP-Glu+ PPi,false")
	push!(reaction_array,"e31,Galactose,Galactose-1P,false")
	push!(reaction_array,"e32,Galactose-1P+UDP-Glu,UDP-Gal+Glucose-1P,false")
	push!(reaction_array,"e33,[],Polypeptide,true")
	push!(reaction_array,"e34,T_Antigen, [], false")
	push!(reaction_array,"e36 ,[],Cosmc,true") #assuming this is introduced in system and is defective
	push!(reaction_array,"e37,[],T_synthase,true")
	push!(reaction_array,"e38,[],A2d,true") 
	push!(reaction_array,"e39,T_complex_in,[],true")
	push!(reaction_array,"e40,T_complex,[],true")

	
	
	(S, species_array, reaction_name_array) = lib.build_stoichiometric_matrix(reaction_array;expand=false);
	

    #show
    nothing
end

# ╔═╡ 005df1c2-d79c-4f34-a20f-c10d427b9caf
S

# ╔═╡ b3538aef-92e9-4793-aebd-57ca3a78fb7a
begin
S	
(M,R)=size(S)
end

# ╔═╡ ebddd53c-0d0e-4f17-8d54-6d5d426430cb
species_array

# ╔═╡ eaa07f2e-1f75-47fe-bcb2-cc5423a01999
S

# ╔═╡ b60bc6c1-093f-4200-82ff-50c44c4a2023
writedlm("Matrix.txt",S)

# ╔═╡ 068502ac-decf-46ac-8696-33ec5a378dc3
reaction_name_array

# ╔═╡ a83f5a1a-4385-4c2b-aaf9-d8dedadd4eb5
begin
K= lib.expa(S);
P = K[:,1:R];#this is the expa matrix
C = K[:,(R + 1):end];
end

# ╔═╡ 9f09dee6-c333-46c3-93e3-3626ec7338aa
P

# ╔═╡ 00000000-0000-0000-0000-000000000001
PLUTO_PROJECT_TOML_CONTENTS = """
[deps]
DelimitedFiles = "8bb1440f-4735-579b-a4ab-409b98df4dab"
LinearAlgebra = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"
PlutoUI = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
PrettyTables = "08abe8d2-0d0c-5749-adfa-8a2ac140af0d"

[compat]
PlutoUI = "~0.7.38"
PrettyTables = "~1.3.1"
"""

# ╔═╡ 00000000-0000-0000-0000-000000000002
PLUTO_MANIFEST_TOML_CONTENTS = """
# This file is machine-generated - editing it directly is not advised

julia_version = "1.7.2"
manifest_format = "2.0"

[[deps.AbstractPlutoDingetjes]]
deps = ["Pkg"]
git-tree-sha1 = "8eaf9f1b4921132a4cff3f36a1d9ba923b14a481"
uuid = "6e696c72-6542-2067-7265-42206c756150"
version = "1.1.4"

[[deps.ArgTools]]
uuid = "0dad84c5-d112-42e6-8d28-ef12dabb789f"

[[deps.Artifacts]]
uuid = "56f22d72-fd6d-98f1-02f0-08ddc0907c33"

[[deps.Base64]]
uuid = "2a0f44e3-6c83-55bd-87e4-b1978d98bd5f"

[[deps.ColorTypes]]
deps = ["FixedPointNumbers", "Random"]
git-tree-sha1 = "024fe24d83e4a5bf5fc80501a314ce0d1aa35597"
uuid = "3da002f7-5984-5a60-b8a6-cbb66c0b333f"
version = "0.11.0"

[[deps.CompilerSupportLibraries_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "e66e0078-7015-5450-92f7-15fbd957f2ae"

[[deps.Crayons]]
git-tree-sha1 = "249fe38abf76d48563e2f4556bebd215aa317e15"
uuid = "a8cc5b0e-0ffa-5ad4-8c14-923d3ee1735f"
version = "4.1.1"

[[deps.DataAPI]]
git-tree-sha1 = "fb5f5316dd3fd4c5e7c30a24d50643b73e37cd40"
uuid = "9a962f9c-6df0-11e9-0e5d-c546b8b5ee8a"
version = "1.10.0"

[[deps.DataValueInterfaces]]
git-tree-sha1 = "bfc1187b79289637fa0ef6d4436ebdfe6905cbd6"
uuid = "e2d170a0-9d28-54be-80f0-106bbe20a464"
version = "1.0.0"

[[deps.Dates]]
deps = ["Printf"]
uuid = "ade2ca70-3891-5945-98fb-dc099432e06a"

[[deps.DelimitedFiles]]
deps = ["Mmap"]
uuid = "8bb1440f-4735-579b-a4ab-409b98df4dab"

[[deps.Downloads]]
deps = ["ArgTools", "LibCURL", "NetworkOptions"]
uuid = "f43a241f-c20a-4ad4-852c-f6b1247861c6"

[[deps.FixedPointNumbers]]
deps = ["Statistics"]
git-tree-sha1 = "335bfdceacc84c5cdf16aadc768aa5ddfc5383cc"
uuid = "53c48c17-4a7d-5ca2-90c5-79b7896eea93"
version = "0.8.4"

[[deps.Formatting]]
deps = ["Printf"]
git-tree-sha1 = "8339d61043228fdd3eb658d86c926cb282ae72a8"
uuid = "59287772-0a20-5a39-b81b-1366585eb4c0"
version = "0.4.2"

[[deps.Hyperscript]]
deps = ["Test"]
git-tree-sha1 = "8d511d5b81240fc8e6802386302675bdf47737b9"
uuid = "47d2ed2b-36de-50cf-bf87-49c2cf4b8b91"
version = "0.0.4"

[[deps.HypertextLiteral]]
git-tree-sha1 = "2b078b5a615c6c0396c77810d92ee8c6f470d238"
uuid = "ac1192a8-f4b3-4bfe-ba22-af5b92cd3ab2"
version = "0.9.3"

[[deps.IOCapture]]
deps = ["Logging", "Random"]
git-tree-sha1 = "f7be53659ab06ddc986428d3a9dcc95f6fa6705a"
uuid = "b5f81e59-6552-4d32-b1f0-c071b021bf89"
version = "0.2.2"

[[deps.InteractiveUtils]]
deps = ["Markdown"]
uuid = "b77e0a4c-d291-57a0-90e8-8db25a27a240"

[[deps.IteratorInterfaceExtensions]]
git-tree-sha1 = "a3f24677c21f5bbe9d2a714f95dcd58337fb2856"
uuid = "82899510-4779-5014-852e-03e436cf321d"
version = "1.0.0"

[[deps.JSON]]
deps = ["Dates", "Mmap", "Parsers", "Unicode"]
git-tree-sha1 = "3c837543ddb02250ef42f4738347454f95079d4e"
uuid = "682c06a0-de6a-54ab-a142-c8b1cf79cde6"
version = "0.21.3"

[[deps.LibCURL]]
deps = ["LibCURL_jll", "MozillaCACerts_jll"]
uuid = "b27032c2-a3e7-50c8-80cd-2d36dbcbfd21"

[[deps.LibCURL_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll", "Zlib_jll", "nghttp2_jll"]
uuid = "deac9b47-8bc7-5906-a0fe-35ac56dc84c0"

[[deps.LibGit2]]
deps = ["Base64", "NetworkOptions", "Printf", "SHA"]
uuid = "76f85450-5226-5b5a-8eaa-529ad045b433"

[[deps.LibSSH2_jll]]
deps = ["Artifacts", "Libdl", "MbedTLS_jll"]
uuid = "29816b5a-b9ab-546f-933c-edad1886dfa8"

[[deps.Libdl]]
uuid = "8f399da3-3557-5675-b5ff-fb832c97cbdb"

[[deps.LinearAlgebra]]
deps = ["Libdl", "libblastrampoline_jll"]
uuid = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"

[[deps.Logging]]
uuid = "56ddb016-857b-54e1-b83d-db4d58db5568"

[[deps.Markdown]]
deps = ["Base64"]
uuid = "d6f4376e-aef5-505a-96c1-9c027394607a"

[[deps.MbedTLS_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "c8ffd9c3-330d-5841-b78e-0817d7145fa1"

[[deps.Mmap]]
uuid = "a63ad114-7e13-5084-954f-fe012c677804"

[[deps.MozillaCACerts_jll]]
uuid = "14a3606d-f60d-562e-9121-12d972cd8159"

[[deps.NetworkOptions]]
uuid = "ca575930-c2e3-43a9-ace4-1e988b2c1908"

[[deps.OpenBLAS_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Libdl"]
uuid = "4536629a-c528-5b80-bd46-f80d51c5b363"

[[deps.OrderedCollections]]
git-tree-sha1 = "85f8e6578bf1f9ee0d11e7bb1b1456435479d47c"
uuid = "bac558e1-5e72-5ebc-8fee-abe8a469f55d"
version = "1.4.1"

[[deps.Parsers]]
deps = ["Dates"]
git-tree-sha1 = "1285416549ccfcdf0c50d4997a94331e88d68413"
uuid = "69de0a69-1ddd-5017-9359-2bf0b02dc9f0"
version = "2.3.1"

[[deps.Pkg]]
deps = ["Artifacts", "Dates", "Downloads", "LibGit2", "Libdl", "Logging", "Markdown", "Printf", "REPL", "Random", "SHA", "Serialization", "TOML", "Tar", "UUIDs", "p7zip_jll"]
uuid = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"

[[deps.PlutoUI]]
deps = ["AbstractPlutoDingetjes", "Base64", "ColorTypes", "Dates", "Hyperscript", "HypertextLiteral", "IOCapture", "InteractiveUtils", "JSON", "Logging", "Markdown", "Random", "Reexport", "UUIDs"]
git-tree-sha1 = "670e559e5c8e191ded66fa9ea89c97f10376bb4c"
uuid = "7f904dfe-b85e-4ff6-b463-dae2292396a8"
version = "0.7.38"

[[deps.PrettyTables]]
deps = ["Crayons", "Formatting", "Markdown", "Reexport", "Tables"]
git-tree-sha1 = "dfb54c4e414caa595a1f2ed759b160f5a3ddcba5"
uuid = "08abe8d2-0d0c-5749-adfa-8a2ac140af0d"
version = "1.3.1"

[[deps.Printf]]
deps = ["Unicode"]
uuid = "de0858da-6303-5e67-8744-51eddeeeb8d7"

[[deps.REPL]]
deps = ["InteractiveUtils", "Markdown", "Sockets", "Unicode"]
uuid = "3fa0cd96-eef1-5676-8a61-b3b8758bbffb"

[[deps.Random]]
deps = ["SHA", "Serialization"]
uuid = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"

[[deps.Reexport]]
git-tree-sha1 = "45e428421666073eab6f2da5c9d310d99bb12f9b"
uuid = "189a3867-3050-52da-a836-e630ba90ab69"
version = "1.2.2"

[[deps.SHA]]
uuid = "ea8e919c-243c-51af-8825-aaa63cd721ce"

[[deps.Serialization]]
uuid = "9e88b42a-f829-5b0c-bbe9-9e923198166b"

[[deps.Sockets]]
uuid = "6462fe0b-24de-5631-8697-dd941f90decc"

[[deps.SparseArrays]]
deps = ["LinearAlgebra", "Random"]
uuid = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"

[[deps.Statistics]]
deps = ["LinearAlgebra", "SparseArrays"]
uuid = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"

[[deps.TOML]]
deps = ["Dates"]
uuid = "fa267f1f-6049-4f14-aa54-33bafae1ed76"

[[deps.TableTraits]]
deps = ["IteratorInterfaceExtensions"]
git-tree-sha1 = "c06b2f539df1c6efa794486abfb6ed2022561a39"
uuid = "3783bdb8-4a98-5b6b-af9a-565f29a5fe9c"
version = "1.0.1"

[[deps.Tables]]
deps = ["DataAPI", "DataValueInterfaces", "IteratorInterfaceExtensions", "LinearAlgebra", "OrderedCollections", "TableTraits", "Test"]
git-tree-sha1 = "5ce79ce186cc678bbb5c5681ca3379d1ddae11a1"
uuid = "bd369af6-aec1-5ad0-b16a-f7cc5008161c"
version = "1.7.0"

[[deps.Tar]]
deps = ["ArgTools", "SHA"]
uuid = "a4e569a6-e804-4fa4-b0f3-eef7a1d5b13e"

[[deps.Test]]
deps = ["InteractiveUtils", "Logging", "Random", "Serialization"]
uuid = "8dfed614-e22c-5e08-85e1-65c5234f0b40"

[[deps.UUIDs]]
deps = ["Random", "SHA"]
uuid = "cf7118a7-6976-5b1a-9a39-7adc72f591a4"

[[deps.Unicode]]
uuid = "4ec0a83e-493e-50e2-b9ac-8f72acf5a8f5"

[[deps.Zlib_jll]]
deps = ["Libdl"]
uuid = "83775a58-1f1d-513f-b197-d71354ab007a"

[[deps.libblastrampoline_jll]]
deps = ["Artifacts", "Libdl", "OpenBLAS_jll"]
uuid = "8e850b90-86db-534c-a0d3-1478176c7d93"

[[deps.nghttp2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850ede-7688-5339-a07c-302acd2aaf8d"

[[deps.p7zip_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "3f19e933-33d8-53b3-aaab-bd5110c3b7a0"
"""

# ╔═╡ Cell order:
# ╠═2b4f2d26-9445-4173-bf60-86d7c9353a79
# ╠═c9f4e2e7-64d4-437d-845e-5968e181c98d
# ╠═75209531-76f3-4385-b153-0b0c9392c96b
# ╠═005df1c2-d79c-4f34-a20f-c10d427b9caf
# ╠═b3538aef-92e9-4793-aebd-57ca3a78fb7a
# ╠═ebddd53c-0d0e-4f17-8d54-6d5d426430cb
# ╠═eaa07f2e-1f75-47fe-bcb2-cc5423a01999
# ╠═b60bc6c1-093f-4200-82ff-50c44c4a2023
# ╠═068502ac-decf-46ac-8696-33ec5a378dc3
# ╠═a83f5a1a-4385-4c2b-aaf9-d8dedadd4eb5
# ╠═9f09dee6-c333-46c3-93e3-3626ec7338aa
# ╟─00000000-0000-0000-0000-000000000001
# ╟─00000000-0000-0000-0000-000000000002
