fileid=fopen("Matrix.txt");
format= "%c";
S=fscanf(fileid,format);
S=str2num(S);
Array_bounds= bounds;

lbarray= Array_bounds(1:43,1);
ubarray= Array_bounds(1:43,2);
R=zeros(33,1);
c=zeros(1,43);

c(5)=1;

%S(:,2)= zeros(size(S(:,2))); %Knockout example

ve= linprog(c,[],[],S,R,lbarray,ubarray);
disp(ve)