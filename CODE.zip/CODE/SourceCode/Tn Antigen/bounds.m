%bounds for the reactions. The driver code will change bounds(5,:) each run
%Units of bounds are in uM/h
%negative flux means reactant is coming IN, and gets consumed
%positive flux means reactant is going OUT, and gets generated

%special comment for line 13- change the ub for v(5) depending on w(1),
%w(2), w(3) so on. The default value is w(1)
function bound= bounds
bounds= [-100	100
 0	    0.135
-100	100
-100	100
0.0123  0.0123  %change me here for TX Bounds as per constants file outputs. Here, TX LB is set to a -100 than the value
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100
-100	100];
bound=bounds;