%This is just a model. This file does not work unless you change parameters
%that are mentioned in the comments in the lines

fileid=fopen("Matrix.txt"); %open the stoichiometric matrix
format= "%c";
S=fscanf(fileid,format);
S=str2num(S);
Array_bounds= bounds; %call the bounds.m file which has the bounds of concern

%(M,R)=size(S)

%lbarray= Array_bounds(1:R,1); R represents the number of reactions in the matrix 
%ubarray= Array_bounds(1:R,2);


%R=zeros(M,1); R is the flux vector 
%c=zeros(1,R); %weights used for objective function 

%c(5)=1; Weight of the flux to maximize/minimize

%S(:,2)= zeros(size(S(:,2))); %Knockout example

%ve= linprog(c,[],[],S,R,lbarray,ubarray);
%disp(ve)

%displays the minimized 