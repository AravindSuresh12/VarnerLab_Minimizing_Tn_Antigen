%Transcription and Translation bounds calculation

%Equation for Wt= Transcription rate-
%Wt= Vt_max*(Gp/Kt+Gp)
%Vt_max= RT*vt/lg * u

Rt=75;  %units in nM- Rt is the RNAP conc- -Vilkhovoy et al.,2017
vt= 50; %units in nt/s- vt is elongation rate -Vilkhovoy et al.,2017
lg=3910; %units in nucleotides- Data calculated from FASTA file
u=0.95; %the promoter model of T7= K/1+K, where K=10nM, K is the T7RNAP conc--Vilkovoy et al.,2017
Gp=5; %units are in nM, chosen from convinience
Kt=116; %units are in nM, Vilkhovoy et al.,2017
conv=1e-3*3600; %converting from nM/s to uM/h
Wt=Rt*vt*u*Gp/((Kt+Gp)*lg)*conv; %units are in uM/h

%for Translation

%equation wx= Vxmax*(mRNA/ Kx + mRNA)
% Vxmax= (Kp*Rx*vx/lp)
%mRNA(t+ del t)= mRNA(t) + (wt- mRNA*lambda)*del t

%Data taken from Vilkhovoy et al 2017
Kp=10; %polysome amplification constant- unitless
Rx=1.6; %Ribosome concentration, units uM
vx=2; %units are aa/s/ribosome
lp=559; %units are aa, taken from protein of interest GALNT1
Kx=45; %units are uM

Vxmax= Kp*Rx*vx/lp;
lambda=0.0833;%degradation of  mRNA in /h BN108598
mRNA= ones(1,5);
mRNA_in=1; % initial mRNA conc at time t=0, is 1um. Data-bn 100022. Assuming 1nt approx has 1nm concentration in vitro- and 1 copy mRNA produced in the transcription process 

%calculation of mRNA time series

deltime= [1,2,3,4]; %units in h

for i=1:length(deltime)
    mRNA(i)= mRNA_in + i*(Wt- lambda*mRNA_in*i);
end

%initial case for bounds(5,1)

%Wx=Vxmax*(mRNA_in/ Kx + mRNA_in);

%other cases for bounds(5,1)- uncomment me for getting different Wx

for i=1:5
Wx(i)= Vxmax*(mRNA(i)/ Kx + mRNA(i)); %Translation rates at different mRNA conc
end

disp(Wt)
disp(Wx)
