%Graphs for all 5 TX minimization for all 4 scenarios

time=[0,1,2,3,4];

arr1=[0.0585	0.0616	0.0549	0.0384	0.0123];%Tn only
arr2=[0.0585	0.0616	0.0549	0.0384	0.0123]; %Tn+Tunica
arr3=[-0.1789	-0.1789	-0.1789	-0.1789	-0.1789]; %T antigen
arr4=[-0.1789	-0.1789	-0.1789	-0.1789	-0.1789];%T + A2d 

hold on

a1=subplot(2,2,1);
plot(time,arr1);
xlabel("Time (h)")
ylabel("Translation rate (um/h)")
title("Tn antigen (Fig 1.1)")

a2= subplot(2,2,2);
plot(time,arr2);
xlabel("Time (h)")
ylabel("Translation rate (um/h)")
title("Tn antigen+ Tunicamycin (Fig 1.2)")

a3= subplot(2,2,3);
plot(time,arr3);
xlabel("Time (h)")
ylabel("Translation rate (um/h)")
title("T antigen (Fig 1.3)")

a4= subplot(2,2,4);
plot(time,arr4);
xlabel("Time (h)")
ylabel("Translation rate (um/h)")
title("T antigen + A2d (Fig 1.4)")

hold off