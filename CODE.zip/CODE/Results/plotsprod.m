%Graphs showing rate of Tn and T antigen production for 5 time scenarios

time= [0,1,2,3,4];
arr1= [-56.9216 -56.2282 -57.7268 -64.267 -71.5621];%Tn antigen only
arr2= [-100	-100 -100 -100 -100]; %Tn antigen +Tunicamycin
arr3= [50 50 50	50 50]; %T antigen production
arr4= [0 0 0 0 0];%T antigen + A2d

hold on

a1=subplot(2,2,1);
plot(time,arr1);
xlabel("Time (h)")
ylabel("Tn antigen rate (uM/h)")
title("Tn antigen- (Fig 2.1)")

a2= subplot(2,2,2);
plot(time,arr2);
xlabel("Time (h)")
ylabel("Tn antigen+ Tunicamycin rate (uM/h)")
title("Tn antigen+ Tunicamycin- (Fig 2.2)")

a3= subplot(2,2,3);
plot(time,arr3);
xlabel("Time (h)")
ylabel(" T antigen rate (uM/h) ")
title("T antigen (Fig 2.3)")

a4= subplot(2,2,4);
plot(time,arr4);
xlabel("Time (h)")
ylabel("T antigen + A2d rate (uM/h) ")
title("T antigen + A2d (Fig 2.4)")

hold off