function [NPi2,sumNTP_str,ATP,UTP,GTP,CTP]= geneSequence(file)
fileID= fopen(file); %opens file
format ='%c'; %char array specifier
k=fscanf(fileID,format); %reads it as a vector
len=length(k); %length of vector of gene
a=0;t=0;g=0;c=0;
for i= 1:len
    if k(i)==' '
        continue
    elseif k(i)=='A'
        a=a+1;
    elseif k(i)=='T'
        t=t+1;
    elseif k(i)=='G'
        g=g+1;
    elseif k(i)=='C'
        c=c+1;
    end
end
A=a;T=t;G=g;C=c;
U=T;
sumNTP= A+U+G+C; %for reaction 2
PPi=num2str(2*sumNTP);
A=num2str(A);
U=num2str(U);
G=num2str(G);
C=num2str(C);
ATP= strcat(A,'*','ATP');
GTP= strcat(G,'*','GTP');
UTP= strcat(U,'*','UTP');
CTP= strcat(C,'*','CTP');
NPi2 =strcat(PPi,'*','Pi');
sumNTP_str= num2str(sumNTP);