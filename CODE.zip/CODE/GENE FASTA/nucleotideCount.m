function [A,U,G,C]= nucleotideCount(file)
fileID= fopen(file); %opens file
format ='%c'; %char array specifier
k=fscanf(fileID,format); %reads it as a vector
len=length(k); %length of vector of gene
a=0;t=0;g=0;c=0;
for i= 1:len
    if k(i)=='A'
        a=a+1;
    elseif k(i)=='T'
        t=t+1;
    elseif k(i)=='G'
        g=g+1;
    elseif k(i)=='C'
        c=c+1;
    end
end
A=num2str(a);
U=num2str(t);
G=num2str(g);
C=num2str(c);
